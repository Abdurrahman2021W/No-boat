
# 🇧🇩 Official Campaign DP Generator (Pro Version)

![License](https://img.shields.io/badge/License-Official-red.svg)
![Version](https://img.shields.io/badge/Version-1.0.0-black.svg)
![Platform](https://img.shields.io/badge/Platform-Web-blue.svg)

এটি একটি হাই-রেজোলিউশন প্রোফাইল পিকচার ফ্রেম জেনারেটর। রাজনৈতিক বা সামাজিক ক্যাম্পেইনের জন্য অফিশিয়াল লুকিং ডিজিটাল সাপোর্ট ইমেজ তৈরি করতে এই টুলটি ডিজাইন করা হয়েছে।

## 🚀 Live Demo
[আপনার-GitHub-লিংক এখানে দিন]

## 🛠 Features
- **Official Branding:** অফিশিয়াল ফন্ট (Unbounded & Hind Siliguri) এবং কালার প্যালেট।
- **Precision Controls:** জুম এবং পজিশনিং স্লাইডার ব্যবহার করে নিখুঁতভাবে ছবি সেট করার সুবিধা।
- **High Resolution:** ১০৮০x১০৮০ পিক্সেল HD আউটপুট (Facebook/WhatsApp এর জন্য উপযুক্ত)।
- **Neo-Brutalist UI:** আধুনিক এবং নজরকাড়া ইউজার ইন্টারফেস।

## ⚠️ "GitHub Repository Already Exists" সমাধান
যদি আপনার GitHub-এ অলরেডি একই নামে রিপোজিটরি থাকে, তবে নতুন করে তৈরি না করে বিদ্যমান রিপোজিটরিতে কোড পুশ করতে নিচের কমান্ডগুলো ব্যবহার করুন:

```bash
# ১. গিট ইনিশিয়ালাইজ করুন (যদি না করা থাকে)
git init

# ২. বিদ্যমান রিপোজিটরির সাথে লিংক সেট করুন
git remote set-url origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git

# ৩. কোড পুশ করুন
git add .
git commit -m "Public Release Version"
git branch -M main
git push -u origin main
```

## 🌐 How to Host on GitHub Pages (Public)
১. আপনার GitHub রিপোজিটরিতে গিয়ে **Settings**-এ ক্লিক করুন।
২. বাম দিকের মেনু থেকে **Pages** সিলেক্ট করুন।
৩. **Build and deployment** সেকশনে:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
৪. **Save** বাটনে ক্লিক করুন। কয়েক মিনিট পর আপনার সাইটটি `https://yourname.github.io/repo-name` লিংকে পাবলিকলি দেখা যাবে।

---
Developed by **Official Media Cell**
